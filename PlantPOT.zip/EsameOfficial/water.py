#Silvia Zottin 147627 - Smart Networked Devices
#Script contenente funzioni di lettura e attivazione dei sensori
import botPlant
import RPi.GPIO as GPIO
from time import sleep
import datetime
import grovepi
from grove.adc import ADC

GPIO.setmode(GPIO.BOARD) #Broadcom pin-numbering scheme
pin_pianta=8 #pin lettura igrometro
pin_pump=7 #pin attivazione pompa
A0=0 #porta analogica per livello dell'acqua
adc = ADC()
conta = 0 #variabile globale con tenere conto dell'attivazione della pompa

#Stato della pianta(se è bagnata o no)
def status_pianta():
        GPIO.setup(pin_pianta, GPIO.IN)
        return GPIO.input(pin_pianta)

#Attiva pompa
def pump_on():
        GPIO.setup(pin_pump, GPIO.OUT) 
        GPIO.output(pin_pump, GPIO.HIGH)

#Spegne pompa
def pump_off():
        GPIO.setup(pin_pump, GPIO.OUT)
        GPIO.output(pin_pump, GPIO.LOW)

#Lettura del valore del livello dell'acqua
def livelloAcqua():
        return adc.read(A0)

#Scrive ora e data dell'ultima innaffiata nel file storico.txt. Se è la prima innaffiatura crea il file e scrive.
def write_last_watered():
        f = open("/home/pi/Desktop/progetti/Esame/storico.txt", "w")
        f.write("L'ultima innaffiata è avvenuta il giorno {} alle ore {}".format(datetime.date.today(), datetime.datetime.now().strftime("%X")))
        f.close()

#Controlla la pianta e decide se ha sete o è a posto
def annaffia ():
        wet= status_pianta()==0 #stato umidità del terreno
        global conta
        if not wet: #pianta asciutta
                if livelloAcqua() < 80:   #Serbatoio vuoto
                        botPlant.avviso (botPlant.chat) #avviso telegram serbatorio vuoto
                else: #serbatoio con acqua
                        pump_on() #attiva pompa
                        sleep(3) #sleep di 3 secondi per far fluire 80 ml di acqua dalla pompa
                        pump_off() #spegnimento pompa
                        write_last_watered() #scrittura su file Storico.txt di data e ora innaffiamento
                        conta +=1 #incremento variabile conta

#avvia in automatico l'innafiamento della pianta attra verso un loop, fino a quando l'utente non decidere di spegnere il vaso
def auto_water(fine):
        while True: #loop fino all'interruzione del thread
                if fine(): #flag per l'interruzione del thread
                        break #interruzione thread
                annaffia() #funzione di annaffiatura
                sleep(60) #sleep di 60 secondi (per un uso realtà del sistema questo incrementa, così da attivare annaffia() 3/4 volte al giorno)