#Silvia Zottin 147627 - Smart Networked Devices
#main.py si avvia all'accensione del Raspberry Pi in automatico
#avvia l'esecuzione del bot di telegram @PlantPotSilvia_bot e un server Flask che reindirizza a una pagina web contenente informazioni sul sistema
#import degli altri tre script: water.py (funzioni di lettura sensori), web.py (collegamenti Server Flask) e botPlant.py (si occupa del bot telegram)
import water
import web
import botPlant

if __name__ == "__main__":
   botPlant.updater.start_polling()
   web.app.run(host="192.168.1.2")