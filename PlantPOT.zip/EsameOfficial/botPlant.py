# Silvia Zottin 147627 - Smart Networked Devices
# Script che si occupa delle funzioni e del collegamento con il bot telegram.
# Username bot: @PlantPotSilvia_bot 
import water
import web
import telegram
from telegram.ext import Updater, CommandHandler
import logging
from selenium import webdriver
from bs4 import BeautifulSoup
import random

#Info creazione bot telegram
token ="1046134958:AAEFzKTE-sKaZZ2s5V0AexFSnNS_nBZTpo8"
chat="17659635"
#Collegamento con bot
updater = Updater (token, use_context=True)
dispatcher = updater.dispatcher
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger=logging.getLogger(__name__)

#/start - comando iniziale per visualizzare le informazioni di PlantPOT
def start(update, context):
        context.bot.send_sticker(chat_id=update.effective_chat.id, sticker='CAACAgIAAxkBAAILR15Bc4-h3_WPjhXpjvyXpuHVRTnYAAJRAAOBFe4zRzgL2BPkfwkYBA')
        context.bot.send_message(chat_id=update.effective_chat.id, text=
                "CIAO!\nMi chiamo *POT* e da oggi mi occupo io della tua pianta.\nPer iniziare devi attivare il vaso all'indirizzo http://192.168.1.2:5000/ .\nIn questo bot ti avviserò quando ci sarà bisogno di riempire il serbatoio.\nPuoi in qualunque momento digitare:\n/acceso per verificare se POT è acceso\n/status per sapere come stà la tua pianta.\n/serbatoio per sapere quanto è piena la mia riserva d'acqua\n/curiosity per chiedermi qualche fun facts, curiosità e consigli sulle piante e fiori.\nPer maggiori informazioni sulla tua pianta visita il sito.",
                parse_mode='MARKDOWN')
        logging.info('Start messagebot')
start_handler=CommandHandler('start', start)
dispatcher.add_handler(start_handler)

#/acceso - verifica se POT è acceso per l'innafiatura automatica
def acceso (update, context):
        if web.acceso==True: #Innaffiatura avviata
                context.bot.send_message(chat_id=update.effective_chat.id, text="POT è acceso!")
        else: #Innaffiatura automatica spenta
                context.bot.send_message(chat_id=update.effective_chat.id, text="POT sta riposando, accendilo al sito http://192.168.1.2:5000/ !")
        logging.info('Accensione vaso.')
stato=CommandHandler('acceso', acceso)
dispatcher.add_handler(stato)

#/status - come sta la pianta, quindi se la terra è asciutta o umida
def status (update, context):
        wet= water.status_pianta()==0 #lettura igrometro
        if wet: #terra umida
                context.bot.send_message(chat_id=update.effective_chat.id, text="La pianta sta bene!")
        else: #terra secca
                context.bot.send_message(chat_id=update.effective_chat.id, text="La pianta ha sete!")
        logging.info('Stato pianta.')
stato=CommandHandler('status', status)
dispatcher.add_handler(stato)

#/serbatoio - controlla il livello dell'acqua nel serbatoio e avvisa dello stato.
# Il sensore misura un livello massimo di circa 250, quindi valore minore di 80 serbatorio vuoto, 80<livello<120 quasi vuoto,
# 120<livello<200 pieno per metà, altrimenti pieno. 
def serbatoio (update, context):
        if water.livelloAcqua() < 80: #serbatoio vuoto
                context.bot.send_message(chat_id=update.effective_chat.id, text="Attento, il serbatoio è vuoto!")
        else:
                if water.livelloAcqua() >120 and water.livelloAcqua() <200: #serbatorio a metà
                        context.bot.send_message(chat_id=update.effective_chat.id, text="Il serbatorio è pieno a metà!")
                else:
                        if water.livelloAcqua() > 80 and water.livelloAcqua() < 120: #serbatoio quasi vuoto
                                context.bot.send_message(chat_id=update.effective_chat.id, text="Attento, l'acqua sta per finire!")
                        else:
                                context.bot.send_message(chat_id=update.effective_chat.id, text="Il serbatoio è pieno :)") #serbatotio pieno
        logging.info('Serbatoio pianta.')
stato=CommandHandler('serbatoio', serbatoio)
dispatcher.add_handler(stato)

#Ricerca nel sito di fun fact e consigli su piante e fiori
#Collegamento tramite pacchetto Selenium e estrazione informazioni pagina html tramite BeautifulSoup 
driver = webdriver.Chrome()
driver.get('http://avasflowers.net/facts-about-flowers-for-kids/')
page=driver.page_source
soup=BeautifulSoup(page, 'html.parser')
quotes=soup.find('div', id='int-main-fullwidth')
scraped=[]
for quote in quotes.find_all("li"):
    text=quote.find("p").text
    scraped.append(text)

#/curiosity - sceglie random una curiosità tra quelle del sito e aggiorna chat
def curiosity(update, context):
        context.bot.send_message(chat_id=update.effective_chat.id, text="{}".format(random.choice(scraped)))
        logging.info('Messaggio di curiosità.')
testo=CommandHandler('curiosity', curiosity)
dispatcher.add_handler(testo)

#Notifica di avviso di serbatoio vuoto
def avviso (chat):
        bot=telegram.Bot(token)
        bot.sendMessage(chat_id=chat, text="Riempimi il serbatoio, è *VUOTO*!", parse_mode='MARKDOWN')
        logging.info('Avviso serbatoio.')

#Notifica di avviso quando si accende innaffiatura automatica POT
def avvisoON (chat):
        bot=telegram.Bot(token)
        bot.sendMessage(chat_id=chat, text="POT si è accesso!", parse_mode='MARKDOWN')
        logging.info('Avviso Accensione.')

#Notifica di avviso quando si spegne innaffiatura automatica POT
def avvisoOFF (chat):
        bot=telegram.Bot(token)
        bot.sendMessage(chat_id=chat, text="POT si è spento!", parse_mode='MARKDOWN')
        logging.info('Avviso Spegnimento.')
