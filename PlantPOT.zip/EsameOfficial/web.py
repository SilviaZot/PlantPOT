#Silvia Zottin 147627 - Smart Networked Devices
#Server Flask che reindirizza alla pagina web main.html, contenente informazioni sul sistema
#Da questa pagina web è possibile accendere l'innaffiatura automatica e spegnerla
import water
import botPlant
from flask import Flask, render_template, redirect, url_for, request
import os
import threading

#Oggetto Flask
app = Flask(__name__)
#variabili flag per avvio di POT
stop_thread = False #flag per stoppare thread
acceso = False #flag che indica l'accensione dell'innaffiatura automatica
#variabili per stato del template
stato="Spento"
color="red"

#template della pagina web
def template(text ="", color="", stato="", colstato=""):
    templateDate ={
          'text' : text,
          'color': color,
          'stato': stato,
          'colstato': colstato
    }
    return templateDate

#determinazione percorso di due immagini per pagina web
IMMAGINE = os.path.join('static', 'immagini')
app.config['UPLOAD_FOLDER'] = IMMAGINE
img_filename = os.path.join(app.config['UPLOAD_FOLDER'], 'sticker.gif')
img2_filename = os.path.join(app.config['UPLOAD_FOLDER'], 'sticker2.gif')

#main                        
@app.route("/")
def main():
    templateData= template(stato=stato, colstato=color)
    return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)

#Stato pianta, quindi se la terra è asciutta o no
@app.route("/sensor")
def statoPianta ():
    wet= water.status_pianta() #lettura igrometro
    if wet==0: #terra umida
        message="La pianta sta bene ed è molto felice!"
    else: #terra secca
        message="La pianta ha sete, se sono rimaste riserve d'acqua a breve berrà!"
    templateData= template(text = message, color ="mediumvioletred", stato=stato, colstato=color)
    return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)

#Quanto ha bevuto la pianta
#Ogni innaffiata sono 80ml, quindi il totale è dato dalla sua moltiplicazione con "conta", variabile per contare l'attivazione della pompa       
@app.route("/bere")
def acquaBevuta ():
        if water.conta>0: #la pompa è stata attivata almeno una volta
                message ="La pianta ha bevuto {} ml di acqua, che ubriacona!".format(water.conta*80)
        else: #la pompa non è mai stata attivata
                message ="La pianta non ha ancora bevuto!"
        templateData= template(text = message, color ="seagreen", stato=stato, colstato=color)
        return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)

#Controlla il livello dell'acqua nel serbatoio e avvisa dello stato.
# Il sensore misura un livello massimo di circa 250, quindi valore minore di 80 serbatorio vuoto, 80<livello<120 quasi vuoto,
# 120<livello<200 pieno per metà, altrimenti pieno. 
@app.route("/serbatoio")
def  acquaSerb():
        if water.livelloAcqua() < 80: #serbatoio vuoto
                message="Attento, il serbatoio è vuoto!"
        else:
                if water.livelloAcqua() > 120 and water.livelloAcqua() < 200: #serbatorio a metà
                        message="Il serbatorio è pieno a metà!"
                else:
                        if water.livelloAcqua() > 80 and water.livelloAcqua() < 120: #serbatoio quasi vuoto
                                message= "Attento, l'acqua sta per finire!"
                        else:
                                message="Il serbatoio è pieno :)" #serbatotio pieno
        templateData= template(text = message, color = "dodgerblue", stato=stato, colstato=color)
        return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)

#Legge ultima innaffiata dal file storico.txt se esiste, altrimenti restituisce una stringa
def read_last_watered():
        try:
                f = open("/home/pi/Desktop/progetti/Esame/storico.txt", "r")
                return f.readline()
        except:
                return "MAI!"

#legge e fornisce la data e l'ora dell'ultima innaffitura
@app.route("/ultimo")
def ultimaInnaffiata ():
        message = read_last_watered() #legge ultima innaffiatura da storico.txt
        templateData= template(text = message, color ="tomato", stato=stato, colstato=color)
        return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)
                
#Accensione dell'innaffiatura automatica
@app.route("/switchON")
def accensione ():
        global acceso
        global stop_thread
        global t1
        global stato
        global color
        if acceso == False: #se è spento si accende tramite lo start di un thread che opera in background rispetto il programma principale
                stop_thread = False
                t1 = threading.Thread(target = water.auto_water, args= (lambda: stop_thread, )) #determinazione del thread con la funzione auto_water
                t1.daemon = True #thread muore quando il principale muore
                t1.start() #avvio thread
                acceso = True
                botPlant.avvisoON(botPlant.chat) #avviso di accensione su telegram
                color="green"
                stato="Acceso"
                templateData= template(text="POT acceso!", color="green", stato=stato, colstato=color)
                return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)
        else: #Pot è già acceso, quindi avvisa che non avviene nessuna azione
                message ="POT è già acceso"
                templateData= template(text = message, color="green", stato=stato, colstato=color)
                return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)

#Spegne innaffiatura automatica 
@app.route("/switchOFF")
def spegnimento ():
        global acceso
        global stop_thread
        global t1
        global stato
        global color
        if acceso == True: #thread in esecuzione
                stop_thread = True
                t1.join()#Aspetta che il thread muoia
                acceso=False
                botPlant.avvisoOFF(botPlant.chat)#avviso su telegram
                water.conta=0 #azzeramento della variabile conta
                try: #rimozione file storico.txt
                        os.remove("/home/pi/Desktop/progetti/Esame/storico.txt")
                except:
                        print("Storico.txt mai creato")
                color="red"
                stato="Spento"
                templateData= template(text ="POT spento!", color="red", stato=stato, colstato=color)
                return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)
        else: #Pot è già spento, quindi avvisa che non avviene nessuna azione
                message ="POT è già spento"
                templateData= template(text = message, color ="red", stato=stato, colstato=color)
                return render_template('main.html', user_image = img_filename, user_image2 = img2_filename, **templateData)